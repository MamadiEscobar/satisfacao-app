
import os, io, csv
from datetime import datetime
from flask import Flask, render_template, request, jsonify, Response
from dotenv import load_dotenv
from openpyxl import Workbook
from db import init_db, get_conn

load_dotenv()

app = Flask(__name__)
init_db()

ADMIN_PATH="/admin_2026"
ADMIN_USER=os.getenv("ADMIN_USER","admin")
ADMIN_PASSWORD=os.getenv("ADMIN_PASSWORD","")
AUTO_REFRESH=int(os.getenv("AUTO_REFRESH_SECONDS","10"))

def check():
    if not ADMIN_PASSWORD: return True
    a=request.authorization
    return a and a.username==ADMIN_USER and a.password==ADMIN_PASSWORD

def need(): return Response("Auth required",401,{"WWW-Authenticate":'Basic realm="Admin"'})

@app.get("/")
def index(): return render_template("index.html")

@app.post("/vote")
def vote():
    v=request.json.get("satisfacao")
    now=datetime.now()
    with get_conn() as c:
        c.execute("INSERT INTO feedback (satisfacao,data,hora) VALUES (?,?,?)",
                  (v, now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S")))
        c.commit()
    return jsonify(ok=True)

@app.get(ADMIN_PATH)
def admin():
    if not check(): return need()
    return render_template("admin.html", refresh=AUTO_REFRESH)

def stats_for(dia=None):
    where=""
    p=[]
    if dia: where="WHERE data=?"; p=[dia]
    with get_conn() as c:
        rows=c.execute(f"SELECT satisfacao,COUNT(*) t FROM feedback {where} GROUP BY satisfacao",p).fetchall()
        total=c.execute(f"SELECT COUNT(*) t FROM feedback {where}",p).fetchone()["t"]
    base={"muito_satisfeito":0,"satisfeito":0,"insatisfeito":0}
    for r in rows: base[r["satisfacao"]]=r["t"]
    perc={k:(base[k]/total*100 if total else 0) for k in base}
    return base,perc,total

@app.get("/api/stats")
def api_stats():
    if not check(): return need()
    b,p,t=stats_for(request.args.get("dia"))
    return jsonify(totais=b,percentagens=p,total=t)

@app.get("/api/history")
def history():
    if not check(): return need()
    page=int(request.args.get("page",1))
    limit=int(request.args.get("limit",20))
    dia=request.args.get("dia")
    where=""
    params=[]
    if dia: where="WHERE data=?"; params=[dia]
    off=(page-1)*limit
    with get_conn() as c:
        total=c.execute(f"SELECT COUNT(*) t FROM feedback {where}",params).fetchone()["t"]
        rows=c.execute(f"SELECT * FROM feedback {where} ORDER BY data DESC,hora DESC LIMIT ? OFFSET ?",params+[limit,off]).fetchall()
    return jsonify(items=[dict(r) for r in rows],total=total,page=page,limit=limit)

@app.get("/export/csv")
def exp_csv():
    if not check(): return need()
    dia=request.args.get("dia")
    rows=history().json["items"]
    s=io.StringIO()
    w=csv.writer(s)
    w.writerow(["id","satisfacao","data","hora"])
    for r in rows: w.writerow([r["id"],r["satisfacao"],r["data"],r["hora"]])
    return Response(s.getvalue(),mimetype="text/csv")

@app.get("/export/xlsx")
def exp_xlsx():
    if not check(): return need()
    rows=history().json["items"]
    wb=Workbook(); ws=wb.active
    ws.append(["id","satisfacao","data","hora"])
    for r in rows: ws.append([r["id"],r["satisfacao"],r["data"],r["hora"]])
    bio=io.BytesIO(); wb.save(bio); bio.seek(0)
    return Response(bio.read(),mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition":"attachment; filename=feedback.xlsx"})
