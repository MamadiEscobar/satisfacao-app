
import sqlite3
from pathlib import Path

DB_PATH = Path("data.sqlite3")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_conn() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            satisfacao TEXT NOT NULL,
            data TEXT NOT NULL,
            hora TEXT NOT NULL
        );
        """)
        conn.commit()
