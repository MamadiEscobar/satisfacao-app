
const btns=document.querySelectorAll('button[data-v]');
const msg=document.getElementById('msg');
let lock=false;
btns.forEach(b=>{
 b.onclick=async()=>{
  if(lock)return;
  lock=true;
  await fetch('/vote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({satisfacao:b.dataset.v})});
  msg.textContent='Obrigado!';
  setTimeout(()=>{msg.textContent='';lock=false},3000);
 }
});
